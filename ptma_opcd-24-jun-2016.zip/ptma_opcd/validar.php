<?php
include "../general/DBCBATCH.php";
include "../general/generales.inc";
include "pfma_validacion_archivos.inc";
include "ptma_opcd.inc";
include "ptfma_demon.inc";
include "validar.inc";

/**
$ResultadoValidacion = fncValidaArchivoV2("01", "","../staging/74.dsv");
**/



$ResultadoValidacion = fncValidaArchivoV2("01", "","../staging/BD160108.DBF");
$ResultadoValidacion = fncValidaArchivoV2("02", "","../staging/BD160208.DBF");
$ResultadoValidacion = fncValidaArchivoV2("03", "","../staging/BD160308.DBF");
$ResultadoValidacion = fncValidaArchivoV2("04", "","../staging/BD160408.DBF");

$ResultadoValidacion = fncValidaArchivoV2("05", "","../staging/BD160508.DBF");
$ResultadoValidacion = fncValidaArchivoV2("06", "","../staging/BD160608.DBF");
$ResultadoValidacion = fncValidaArchivoV2("07", "","../staging/BD160708.DBF");
$ResultadoValidacion = fncValidaArchivoV2("08", "","../staging/BD160808.DBF");

$ResultadoValidacion = fncValidaArchivoV2("09", "","../staging/BD160908.DBF");
$ResultadoValidacion = fncValidaArchivoV2("10", "","../staging/BD161008.DBF");
$ResultadoValidacion = fncValidaArchivoV2("11", "","../staging/BD161108.DBF");
$ResultadoValidacion = fncValidaArchivoV2("12", "","../staging/BD161208.DBF");

$ResultadoValidacion = fncValidaArchivoV2("13", "","../staging/BD161308.DBF");
$ResultadoValidacion = fncValidaArchivoV2("14", "","../staging/BD161408.DBF");
$ResultadoValidacion = fncValidaArchivoV2("15", "","../staging/BD161508.DBF");
$ResultadoValidacion = fncValidaArchivoV2("16", "","../staging/BD161608.DBF");

$ResultadoValidacion = fncValidaArchivoV2("17", "","../staging/BD161708.DBF");
$ResultadoValidacion = fncValidaArchivoV2("18", "","../staging/BD161808.DBF");
$ResultadoValidacion = fncValidaArchivoV2("19", "","../staging/BD161908.DBF");
$ResultadoValidacion = fncValidaArchivoV2("20", "","../staging/BD162008.DBF");

$ResultadoValidacion = fncValidaArchivoV2("21", "","../staging/BD162108.DBF");
$ResultadoValidacion = fncValidaArchivoV2("22", "","../staging/BD162208.DBF");
$ResultadoValidacion = fncValidaArchivoV2("23", "","../staging/BD162308.DBF");
$ResultadoValidacion = fncValidaArchivoV2("24", "","../staging/BD162408.DBF");

$ResultadoValidacion = fncValidaArchivoV2("25", "","../staging/BD162508.DBF");
$ResultadoValidacion = fncValidaArchivoV2("26", "","../staging/BD162608.DBF");
$ResultadoValidacion = fncValidaArchivoV2("27", "","../staging/BD162708.DBF");
$ResultadoValidacion = fncValidaArchivoV2("28", "","../staging/BD162808.DBF");

$ResultadoValidacion = fncValidaArchivoV2("29", "","../staging/BD162908.DBF");
$ResultadoValidacion = fncValidaArchivoV2("30", "","../staging/BD163008.DBF");
$ResultadoValidacion = fncValidaArchivoV2("31", "","../staging/BD163108.DBF");
$ResultadoValidacion = fncValidaArchivoV2("32", "","../staging/BD163208.DBF");



?>