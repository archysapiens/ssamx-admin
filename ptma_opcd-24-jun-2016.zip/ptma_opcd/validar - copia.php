<?php
include "../general/DBCBATCH.php";
include "../general/generales.inc";
include "pfma_validacion_archivos.inc";
include "ptma_opcd.inc";
include "ptfma_demon.inc";

$ResultadoValidacion = fncValidaArchivo("01", "","../staging/BD160108.DBF");
$ResultadoValidacion = fncValidaArchivo("02", "","../staging/BD160208.DBF");
$ResultadoValidacion = fncValidaArchivo("03", "","../staging/BD160308.DBF");
$ResultadoValidacion = fncValidaArchivo("04", "","../staging/BD160408.DBF");

$ResultadoValidacion = fncValidaArchivo("05", "","../staging/BD160508.DBF");
$ResultadoValidacion = fncValidaArchivo("06", "","../staging/BD160608.DBF");
$ResultadoValidacion = fncValidaArchivo("07", "","../staging/BD160708.DBF");
$ResultadoValidacion = fncValidaArchivo("08", "","../staging/BD160808.DBF");

$ResultadoValidacion = fncValidaArchivo("09", "","../staging/BD160908.DBF");
$ResultadoValidacion = fncValidaArchivo("10", "","../staging/BD161008.DBF");
$ResultadoValidacion = fncValidaArchivo("11", "","../staging/BD161108.DBF");
$ResultadoValidacion = fncValidaArchivo("12", "","../staging/BD161208.DBF");

$ResultadoValidacion = fncValidaArchivo("13", "","../staging/BD161308.DBF");
$ResultadoValidacion = fncValidaArchivo("14", "","../staging/BD161408.DBF");
$ResultadoValidacion = fncValidaArchivo("15", "","../staging/BD161508.DBF");
$ResultadoValidacion = fncValidaArchivo("16", "","../staging/BD161608.DBF");

$ResultadoValidacion = fncValidaArchivo("17", "","../staging/BD161708.DBF");
$ResultadoValidacion = fncValidaArchivo("18", "","../staging/BD161808.DBF");
$ResultadoValidacion = fncValidaArchivo("19", "","../staging/BD161908.DBF");
$ResultadoValidacion = fncValidaArchivo("20", "","../staging/BD162008.DBF");

$ResultadoValidacion = fncValidaArchivo("21", "","../staging/BD162108.DBF");
$ResultadoValidacion = fncValidaArchivo("22", "","../staging/BD162208.DBF");
$ResultadoValidacion = fncValidaArchivo("23", "","../staging/BD162308.DBF");
$ResultadoValidacion = fncValidaArchivo("24", "","../staging/BD162408.DBF");

$ResultadoValidacion = fncValidaArchivo("25", "","../staging/BD162508.DBF");
$ResultadoValidacion = fncValidaArchivo("26", "","../staging/BD162608.DBF");
$ResultadoValidacion = fncValidaArchivo("27", "","../staging/BD162708.DBF");
$ResultadoValidacion = fncValidaArchivo("28", "","../staging/BD162808.DBF");

$ResultadoValidacion = fncValidaArchivo("29", "","../staging/BD162908.DBF");
$ResultadoValidacion = fncValidaArchivo("30", "","../staging/BD163008.DBF");
$ResultadoValidacion = fncValidaArchivo("31", "","../staging/BD163108.DBF");
$ResultadoValidacion = fncValidaArchivo("32", "","../staging/BD163208.DBF");

?>