<?php

for ($i=0;$i< 10000;$i++){
	echo "Hola";
	sleep (2);
}

?>